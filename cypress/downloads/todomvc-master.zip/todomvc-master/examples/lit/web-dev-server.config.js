export default {
    nodeResolve: {
        exportConditions: ["development", "browser"],
    },
};
